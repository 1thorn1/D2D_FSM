#include "pch.h"
#include "Component.h"

Component::Component()
{
}

Component::~Component()
{
}

void Component::Update()
{
}

void Component::Render()
{
}

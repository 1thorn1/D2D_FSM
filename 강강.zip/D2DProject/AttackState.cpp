#include "AttackState.h"

void AttackState::Enter()
{
}

void AttackState::Update()
{
}

void AttackState::Exit()
{
}

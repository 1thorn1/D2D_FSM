#include "MoveState.h"

void MoveState::Enter()
{
}

void MoveState::Update()
{
}

void MoveState::Exit()
{
}

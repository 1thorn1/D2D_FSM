#include "DeathState.h"

void DeathState::Enter()
{
}

void DeathState::Update()
{
}

void DeathState::Exit()
{
}
